package com.example.ladapp;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    //Define UI Elements:
    private Switch enableSw;
    private Button btnS, btnF, btnB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Initialize UI Elements:
        btnS = findViewById(R.id.btnStop);
        btnF = findViewById(R.id.btnForward);
        btnB = findViewById(R.id.btnBackward);
        enableSw = findViewById(R.id.enableSwitch);
        //Initially disable Manual Control UI Elements & Switch:
        enableSw.setChecked(false);
        enableManualControls(false);
        //Respond to switch being flipped:
        enableSw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                enableManualControls(isChecked);
            }
        });
        //Respond to Emergency Stop being pressed:
        btnS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enableSw.setChecked(false);
                enableManualControls(false);
                //Send the Emergency Stop Command to the Server
                //Asdf...
            }
        });
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.floatingActionButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    public void driveForward(View view){
        //Send the drive forwards command to the server.

    }

    public void driveBackward(View view){
        //Send the drive backwards command to the server.

    }

    public void enableManualControls(Boolean changeTo){
        //Enables all 3 Control UI Buttons
        btnB.setEnabled(changeTo);
        btnF.setEnabled(changeTo);
        btnS.setEnabled(changeTo);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
